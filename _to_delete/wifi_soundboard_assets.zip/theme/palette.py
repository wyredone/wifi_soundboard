PALETTE = {
    "bg": "#0A0B12",
    "surface": "#121524",
    "elevated": "#1A1F33",
    "cyan": "#00E5FF",
    "magenta": "#FF2BD6",
    "violet": "#8B5CFF",
    "lime": "#79FF89",
    "amber": "#FFC857",
    "red": "#FF4D6D",
    "text": "#F4F7FF",
    "muted": "#96A0BD",
    "line": "#2A3150"
}
