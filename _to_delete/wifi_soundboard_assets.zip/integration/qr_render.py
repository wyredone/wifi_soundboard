"""
qr_render.py - compose a live LAN QR code into qr/qr_frame.svg safe area.

    pip install qrcode pillow
    python qr_render.py http://192.168.1.10:5000 out.png
"""
import subprocess
import sys

try:
    import qrcode
    from PIL import Image
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "qrcode", "pillow", "cairosvg"])
    import qrcode
    from PIL import Image

import cairosvg

FRAME_SVG = "assets/qr/qr_frame.svg"
# safe area inside the frame, in frame coordinates (480 x 560 viewBox)
SAFE = (76, 128, 328, 328)
SCALE = 2          # render frame at 2x -> 960 x 1120


def build(url: str, out: str = "connect_card.png") -> str:
    cairosvg.svg2png(url=FRAME_SVG, write_to="_frame.png", scale=SCALE)
    frame = Image.open("_frame.png").convert("RGBA")

    qr = qrcode.QRCode(version=None, error_correction=qrcode.constants.ERROR_CORRECT_H,
                       box_size=10, border=0)
    qr.add_data(url)
    qr.make(fit=True)
    img = qr.make_image(fill_color="#0A0B12", back_color="white").convert("RGBA")

    x, y, w, h = [v * SCALE for v in SAFE]
    img = img.resize((w, h), Image.NEAREST)
    frame.alpha_composite(img, (x, y))

    # re-stamp the center logo seal on top of the QR (ERROR_CORRECT_H tolerates it)
    cairosvg.svg2png(url="assets/logo/logo_tile.svg", write_to="_seal.png",
                     output_width=int(92 * SCALE), output_height=int(92 * SCALE))
    seal = Image.open("_seal.png").convert("RGBA")
    frame.alpha_composite(seal, (int((480 * SCALE - seal.width) / 2),
                                 int(292 * SCALE - seal.height / 2)))
    frame.save(out)
    return out


if __name__ == "__main__":
    url = sys.argv[1] if len(sys.argv) > 1 else "http://192.168.1.10:5000"
    out = sys.argv[2] if len(sys.argv) > 2 else "connect_card.png"
    print(build(url, out))
