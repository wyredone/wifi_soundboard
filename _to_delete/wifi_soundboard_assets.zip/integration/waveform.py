"""
waveform.py - draw real audio peaks with QPainter instead of shipping bitmaps.

    pip install PySide6 numpy soundfile
"""
import subprocess
import sys

try:
    import numpy as np
    import soundfile as sf
    from PySide6.QtCore import QRectF, Qt
    from PySide6.QtGui import QColor, QPainter, QPixmap
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install",
                           "PySide6", "numpy", "soundfile"])
    import numpy as np
    import soundfile as sf
    from PySide6.QtCore import QRectF, Qt
    from PySide6.QtGui import QColor, QPainter, QPixmap

PALETTE = {"neutral": "#96A0BD", "hover": "#00E5FF", "active": "#79FF89",
           "selected": "#FF2BD6"}


def peaks(path: str, buckets: int = 46):
    data, _ = sf.read(path, dtype="float32", always_2d=True)
    mono = data.mean(axis=1)
    if mono.size == 0:
        return [0.0] * buckets
    chunks = np.array_split(np.abs(mono), buckets)
    vals = np.array([c.max() if c.size else 0.0 for c in chunks])
    peak = vals.max() or 1.0
    return (vals / peak).tolist()


def waveform_pixmap(path: str, w: int = 320, h: int = 120, state: str = "neutral",
                    progress: float | None = None, dpr: float = 2.0) -> QPixmap:
    vals = peaks(path)
    pm = QPixmap(int(w * dpr), int(h * dpr))
    pm.setDevicePixelRatio(dpr)
    pm.fill(QColor("#121524" if state == "neutral" else "#1A1F33"))
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing)
    p.scale(dpr, dpr)
    col = QColor(PALETTE[state])
    col.setAlphaF(0.55 if state == "neutral" else 0.95)
    p.setBrush(col)
    p.setPen(Qt.NoPen)
    step = (w - 28) / len(vals)
    for i, v in enumerate(vals):
        bh = max(4.0, v * (h - 40))
        p.drawRoundedRect(QRectF(14 + i * step, (h - bh) / 2, step * 0.55, bh),
                          step * 0.28, step * 0.28)
    if progress is not None:
        p.setPen(QColor("#F4F7FF"))
        x = 14 + progress * (w - 28)
        p.drawLine(int(x), 12, int(x), h - 12)
    p.end()
    return pm
