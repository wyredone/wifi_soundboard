"""
assets.py - asset locator + QIcon helpers for the WiFi Soundboard PySide6 GUI.

Drop the whole `assets/` folder next to this file, e.g.

    project/
      gui/
        assets.py
        assets/            <- this asset pack
        main.py

Usage:
    from assets import A, nav_icon, tray_icon, status_icon, load_theme
    load_theme(app)
    btn.setIcon(nav_icon("server"))
    tray.setIcon(tray_icon("online"))
"""
from __future__ import annotations

import json
import os

try:
    from PySide6.QtCore import QSize
    from PySide6.QtGui import QIcon, QPixmap
except Exception:                                     # allows non-GUI imports
    QIcon = QPixmap = QSize = None                    # type: ignore

BASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")


def path(*parts: str) -> str:
    """Absolute path to an asset inside the pack."""
    return os.path.join(BASE, *parts)


with open(path("theme", "palette.json"), "r", encoding="utf-8") as _f:
    PALETTE = json.load(_f)["colors"]


class A:
    """Common asset shortcuts."""
    APP_ICO = path("icons", "app", "wifi_soundboard.ico")
    LOGO_MARK = path("logo", "logo_mark.svg")
    LOGO_MARK_GLOW = path("logo", "logo_mark_glow.svg")
    LOGO_LOCKUP = path("logo", "logo_lockup.svg")
    LOGO_TILE = path("logo", "logo_tile.svg")
    FAVICON = path("logo", "favicon.ico")
    SPLASH_LANDSCAPE = path("splash", "splash_1280x720.png")
    SPLASH_PORTRAIT = path("splash", "splash_720x900.png")
    QR_FRAME = path("qr", "qr_frame.svg")
    NETWORK_DIAGRAM = path("diagrams", "network_flow.svg")
    GRID_TILE = path("textures", "bg_grid_tile.png")
    SCANLINE_TILE = path("textures", "bg_scanline_tile.png")
    QSS = path("theme", "neon.qss")


def _icon(p: str):
    if QIcon is None:
        raise RuntimeError("PySide6 is not available")
    return QIcon(p)


def nav_icon(name: str, state: str = "") -> "QIcon":
    """nav_icon('server') | nav_icon('server', 'active') | nav_icon('server', 'muted')"""
    suffix = f"_{state}" if state else ""
    return _icon(path("icons", "nav", f"icon_{name}{suffix}.svg"))


def audio_icon(name: str, state: str = "") -> "QIcon":
    suffix = f"_{state}" if state else ""
    return _icon(path("icons", "audio", f"icon_{name}{suffix}.svg"))


def library_icon(name: str, state: str = "") -> "QIcon":
    suffix = f"_{state}" if state else ""
    return _icon(path("icons", "library", f"icon_{name}{suffix}.svg"))


def category_icon(name: str) -> "QIcon":
    return _icon(path("icons", "category", f"icon_{name}.svg"))


def device_icon(name: str) -> "QIcon":
    return _icon(path("icons", "device", f"icon_{name}.svg"))


def status_icon(state: str) -> "QIcon":
    """state: online | offline | starting | warning | locked | lan_visible"""
    return _icon(path("icons", "status", f"icon_server_{state}.svg"))


def activity_icon(kind: str) -> "QIcon":
    """kind: connect | disconnect | played | uploaded | warning | error"""
    return _icon(path("icons", "activity", f"icon_activity_{kind}.svg"))


def tray_icon(state: str, light_theme: bool = False) -> "QIcon":
    """state: online | offline | starting | error | playing"""
    suffix = "_light" if light_theme else ""
    ico = QIcon()
    for size in (16, 20, 24, 32, 48):
        p = path("icons", "tray", "png", f"tray_{state}{suffix}_{size}.png")
        if os.path.exists(p):
            ico.addFile(p, QSize(size, size))
    if ico.isNull():
        ico = _icon(path("icons", "tray", f"tray_{state}{suffix}.svg"))
    return ico


def badge(name: str) -> "QPixmap":
    """name: live | new | hotkey | loop | favorite | playing | offline | muted"""
    return QPixmap(path("badges", f"badge_{name}.png"))


def empty_state(name: str) -> "QPixmap":
    """name: no_sounds | no_clients | server_stopped | no_results | no_logs | upload_dropzone"""
    return QPixmap(path("empty_states", f"empty_{name}.png"))


def waveform_frame(state: str = "neutral") -> "QPixmap":
    """state: neutral | hover | active | selected"""
    return QPixmap(path("waveform_frames", f"waveform_{state}.png"))


def load_theme(app) -> None:
    """Apply neon.qss and the app icon to a QApplication."""
    with open(A.QSS, "r", encoding="utf-8") as f:
        app.setStyleSheet(f.read())
    if QIcon is not None:
        app.setWindowIcon(QIcon(A.APP_ICO))
