"""
demo_shell.py - runnable PySide6 preview of the WiFi Soundboard asset pack.

    pip install PySide6
    python demo_shell.py

Requires `assets.py` and the `assets/` folder in the same directory.
"""
import subprocess
import sys

try:
    from PySide6 import QtCore, QtGui, QtWidgets
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "PySide6"])
    from PySide6 import QtCore, QtGui, QtWidgets

from assets import (A, PALETTE, activity_icon, badge, device_icon, empty_state,
                    load_theme, nav_icon, status_icon, tray_icon, waveform_frame)

NAV = [("dashboard", "Dashboard"), ("sounds", "Sound Library"), ("upload", "Upload"),
       ("clients", "Clients"), ("server", "Server"), ("logs", "Logs"),
       ("settings", "Settings"), ("help", "Help")]


class Window(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("WiFi Soundboard - Asset Preview")
        self.resize(1180, 720)

        central = QtWidgets.QWidget()
        root = QtWidgets.QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        nav = QtWidgets.QListWidget()
        nav.setObjectName("Nav")
        nav.setFixedWidth(214)
        nav.setIconSize(QtCore.QSize(20, 20))
        for key, label in NAV:
            item = QtWidgets.QListWidgetItem(nav_icon(key), label)
            nav.addItem(item)
        nav.setCurrentRow(0)
        root.addWidget(nav)

        body = QtWidgets.QWidget()
        grid = QtWidgets.QGridLayout(body)
        grid.setContentsMargins(22, 22, 22, 22)
        grid.setSpacing(16)

        head = QtWidgets.QHBoxLayout()
        logo = QtWidgets.QLabel()
        logo.setPixmap(QtGui.QIcon(A.LOGO_LOCKUP).pixmap(360, 80))
        head.addWidget(logo)
        head.addStretch(1)
        pill = QtWidgets.QLabel("  SERVER ONLINE")
        pill.setObjectName("StatusOnline")
        pill.setPixmap(status_icon("online").pixmap(16, 16))
        pill.setText("SERVER ONLINE")
        head.addWidget(pill)
        for text, oid in (("Start", "Primary"), ("Restart", ""), ("Stop", "Danger")):
            b = QtWidgets.QPushButton(text)
            if oid:
                b.setObjectName(oid)
            head.addWidget(b)
        grid.addLayout(head, 0, 0, 1, 3)

        def card(title, widget):
            box = QtWidgets.QFrame()
            box.setObjectName("Card")
            lay = QtWidgets.QVBoxLayout(box)
            lay.setContentsMargins(16, 14, 16, 16)
            cap = QtWidgets.QLabel(title)
            cap.setObjectName("H2")
            lay.addWidget(cap)
            lay.addWidget(widget)
            return box

        qr = QtWidgets.QLabel()
        qr.setPixmap(QtGui.QIcon(A.QR_FRAME).pixmap(260, 300))
        grid.addWidget(card("CONNECT A DEVICE", qr), 1, 0, 2, 1)

        wave = QtWidgets.QLabel()
        wave.setPixmap(waveform_frame("active"))
        grid.addWidget(card("NOW PLAYING", wave), 1, 1)

        badges = QtWidgets.QWidget()
        bl = QtWidgets.QHBoxLayout(badges)
        bl.setContentsMargins(0, 0, 0, 0)
        for name in ("live", "playing", "hotkey", "loop", "new"):
            lbl = QtWidgets.QLabel()
            lbl.setPixmap(badge(name).scaledToHeight(26, QtCore.Qt.SmoothTransformation))
            bl.addWidget(lbl)
        bl.addStretch(1)
        grid.addWidget(card("BADGES", badges), 2, 1)

        clients = QtWidgets.QTableWidget(3, 3)
        clients.setHorizontalHeaderLabels(["DEVICE", "ADDRESS", "STATE"])
        clients.horizontalHeader().setStretchLastSection(True)
        clients.verticalHeader().hide()
        for row, (dev, ip, st) in enumerate((("phone", "192.168.1.42", "connect"),
                                            ("browser", "192.168.1.51", "played"),
                                            ("desktop", "192.168.1.10", "disconnect"))):
            clients.setItem(row, 0, QtWidgets.QTableWidgetItem(device_icon(dev), dev.title()))
            clients.setItem(row, 1, QtWidgets.QTableWidgetItem(ip))
            clients.setItem(row, 2, QtWidgets.QTableWidgetItem(activity_icon(st), st))
        grid.addWidget(card("CLIENTS", clients), 1, 2)

        empty = QtWidgets.QLabel()
        empty.setPixmap(empty_state("no_sounds").scaledToWidth(300, QtCore.Qt.SmoothTransformation))
        empty.setAlignment(QtCore.Qt.AlignCenter)
        grid.addWidget(card("EMPTY STATE", empty), 2, 2)

        root.addWidget(body, 1)
        self.setCentralWidget(central)

        self.tray = QtWidgets.QSystemTrayIcon(tray_icon("online"), self)
        menu = QtWidgets.QMenu()
        for state in ("online", "offline", "starting", "error", "playing"):
            menu.addAction(tray_icon(state), state.title(),
                           lambda s=state: self.tray.setIcon(tray_icon(s)))
        menu.addSeparator()
        menu.addAction("Quit", QtWidgets.QApplication.quit)
        self.tray.setContextMenu(menu)
        self.tray.setToolTip("WiFi Soundboard - online")
        self.tray.show()


def main():
    app = QtWidgets.QApplication(sys.argv)
    load_theme(app)
    splash = QtWidgets.QSplashScreen(QtGui.QPixmap(A.SPLASH_LANDSCAPE).scaledToWidth(
        820, QtCore.Qt.SmoothTransformation))
    splash.show()
    app.processEvents()
    win = Window()
    QtCore.QTimer.singleShot(1200, lambda: (splash.finish(win), win.show()))
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
